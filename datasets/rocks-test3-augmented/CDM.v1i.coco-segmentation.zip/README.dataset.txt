# CDM > 2022-10-04 9:31am
https://universe.roboflow.com/object-detection/cdm-b4yrh

Provided by Roboflow
License: CC BY 4.0

